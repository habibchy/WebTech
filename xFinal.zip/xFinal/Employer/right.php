<?php
if(!isset($_SESSION))
{
session_start();
}
?>

<div id="col" class="noprint">
            <div id="col-in">

                <h3>Welcome</h3>

                <div id="about-me">
                    <p>
                    <?php 
					echo $_SESSION['Name'];
					?>
                    </p>
              </div>
                <hr class="noscreen" />
                <h3 >&nbsp;</h3>

              <br/>

      <hr class="noscreen" />
                <h3>&nbsp;</h3>

                <br/>

            <hr class="noscreen" />
                <h3>&nbsp;</h3>
<br/>

<hr class="noscreen" />
          </div>
</div> 
