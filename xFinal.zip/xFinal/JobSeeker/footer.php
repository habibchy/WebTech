    <div id="footer">
        <hr class="noscreen" />
        
        <p  id="createdby">
          
        </p>
        <p id="copyright">&copy; jobportal.com</p>
  </div>