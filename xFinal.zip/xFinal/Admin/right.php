<div id="col" class="noprint">
            <div id="col-in">
                <h3>Welcome</h3>

                <div id="about-me">
                    <p>Administrator<br />
                    </p>
              </div>

                <hr class="noscreen" />
                <h3 >&nbsp;</h3>

              <br/>

      <hr class="noscreen" />
                <h3>&nbsp;</h3>

                <br/>

            <hr class="noscreen" />

         
                <h3>&nbsp;</h3>
<br/>

<hr class="noscreen" />
          </div>
</div> 

