 <div id="footer">
       
        <hr class="noscreen" />
        
        <p class="style1" id="createdby">
        </p>
        <p id="copyright">&copy; job_portal123.com</p>
  </div>