<?php
function updateDB($sql){
	$conn = mysqli_connect("localhost", "root", "", "yo");
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	if(mysqli_query($conn, $sql)) {
		echo "New records updated successfully";
	}
	else{
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
}
function getExt($filename){
	//abc.jpg
	$a=explode(".",$filename);
	return $a[1];
}
function updateSQL($sql){
	$conn = mysqli_connect("localhost", "root", "","yo");
	//echo $sql;
	$result = mysqli_query($conn,$sql)or die(mysqli_error($conn));
	return $result;
}
function loadFromText(){
	global $auth;
	$myfile = fopen("crd.txt", "r") or die("Unable to open file!");
	$auth=array();
	while($line=fgets($myfile)) {	// read all lines until end-of-file
		$ar=explode(" ",$line);
		$auth[]=array("id"=>$ar[0],"uname"=>$ar[1],"pass"=>$ar[2],"email"=>$ar[3]);
	}
	//print_r($auth);
}

function getJSONFromDB($sql){
	$conn = mysqli_connect("localhost", "root", "","yo");
	//echo $sql;
	$result = mysqli_query($conn, $sql)or die(mysqli_error($$conn));
	$arr=array();
	//print_r($result);
	while($row = mysqli_fetch_assoc($result)) {
		$arr[]=$row;
	}
	return json_encode($arr);
}

function loadFromXML(){
	global $auth;
    $auth=array();
	$xml=simplexml_load_file("cred.xml") or die("Error: Cannot create object");

	foreach($xml->user as $st){
		$ar=array();
		$ar["uname"]=(string)$st->uname;
		$ar["pass"]=(string)$st->pass;
		$auth[]=$ar;
	}
	//print_r($auth);
}
function loadFromMySQL($sql){
	global $data;
	$conn = mysqli_connect("localhost", "root", "","yo");
	//echo $sql;
	$result = mysqli_query($conn, $sql)or die(mysqli_error($conn));
	$data=array();
	//print_r($result);
	while($row = mysqli_fetch_assoc($result)) {
		$data[]=$row;
	}
	//return $arr;
}

?>