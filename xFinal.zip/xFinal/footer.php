    <div id="footer">
        <hr class="noscreen" />      
        <p class="style1">
        </p>
        <p id="copyright">&copy;  job_portal123.com</p>
</div>