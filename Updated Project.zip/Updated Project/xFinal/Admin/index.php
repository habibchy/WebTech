<?php

session_start();
if(isset($_SESSION["flag"]) && $_SESSION["flag"]=="pattern123")
{
    
    
?>

<script>
var xmlhttp = new XMLHttpRequest();
xmlhttp.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
    var myObj = JSON.parse(this.responseText);
    document.getElementById("demo").innerHTML = myObj.name;
  }
};
xmlhttp.open("GET", "db_rw.php", true);
xmlhttp.send();
</script>
<!--
<script>
   $(document).click(function(){
        if(typeof timeOutObj != "undefined") {
            clearTimeout(timeOutObj);
        }

        timeOutObj = setTimeout(function(){ 
            localStorage.clear();
            window.location = "/";
        }, 60000);   //will expire after 1 minutes

   });
</script>
<--->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="content-language" content="cs" />
    <meta name="robots" content="all,follow" />

    <meta name="author" content="All: ... [Nazev webu - www.url.cz]; e-mail: info@url.cz" />
    <meta name="copyright" content="Design/Code: Vit Dlouhy [Nuvio - www.nuvio.cz]; e-mail: vit.dlouhy@nuvio.cz" />
    
    <title>JOB PORTAL</title>
    <meta name="description" content="..." />
    <meta name="keywords" content="..." />
    
    <link rel="index" href="./" title="Home" />
    <link rel="stylesheet" media="screen,projection" type="text/css" href="./css/main.css" />
    <link rel="stylesheet" media="print" type="text/css" href="./css/print.css" />
    <link rel="stylesheet" media="aural" type="text/css" href="./css/aural.css" />
    <style type="text/css">
    </style>
</head>

<body id="www-url-cz">
<div id="main" class="box">
<?php 
include "Header.php"
?>
<?php 
include "menu.php"
?>   
    <div id="page" class="box">
    <div id="page-in" class="box">

        <div id="strip" class="box noprint">
            <hr class="noscreen" />
            <p id="breadcrumbs">You are here: <a href="index.php">Home</a></p>
          <hr class="noscreen" />                         
        </div>       
        <div id="content">         
            <hr class="noscreen" />
            <hr class="noscreen" />
            <hr class="noscreen" />
            <div class="article">
                <h2><span><a href="#">Welcome To Control Panel</a></span></h2>
                <p>&nbsp;</p>
              <p class="btn-more box noprint">&nbsp;</p>              
              <form action="upload.php" method="post" enctype="multipart/form-data" name="mfm"><pre>
	Your Name : 	<input type="text" name="uName">
	Select file to upload : <input type="file" name="fileToUpload">
	<input type="submit" value="Upload File" onclick="return validate();" name="submit">
	</pre>
</form>           
       <?php        
         $data=array();
include("db_rw.php");
//loadFromMySQL("select * from pic where name='".$_GET["name"]."'");
loadFromMySQL("select * from pic");

foreach($data as $v){
	echo "<p>";
	echo $v["name"];
	echo ":";
	
	if(file_exists($v["purl"]))
		echo "<img alt='not found' src='".$v["purl"]."' width='100px' height='40px'/>";
	else
		echo "Image missing";
	echo "</p>";
 }

    ?>               
        </div>

            <hr class="noscreen" />
            
        </div>
<?php
include "right.php"
?>

    </div>
    </div>
 
<?php
include "footer.php"
?>
</div>

</body>
</html>

<?php
}
   else{
       header("Location:../index.php?error=invalid user");
   }        
        
?>
