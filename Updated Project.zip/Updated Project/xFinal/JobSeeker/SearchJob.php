<?php

session_start();
if(isset($_SESSION["flag"]) && $_SESSION["flag"]=="pattern123")
{
    
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search</title>
    
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="content-language" content="cs" />
    <meta name="robots" content="all,follow" />

    <meta name="author" content="All: ... [Nazev webu - www.url.cz]; e-mail: info@url.cz" />
    <meta name="copyright" content="Design/Code: Vit Dlouhy [Nuvio - www.nuvio.cz]; e-mail: vit.dlouhy@nuvio.cz" />
    
    <title>JOB PORTAL</title>
    <meta name="description" content="..." />
    <meta name="keywords" content="..." />
    
    <link rel="index" href="./" title="Home" />
    <link rel="stylesheet" media="screen,projection" type="text/css" href="./css/main.css" />
    <link rel="stylesheet" media="print" type="text/css" href="./css/print.css" />
    <link rel="stylesheet" media="aural" type="text/css" href="./css/aural.css" />
    <style type="text/css">
    </style>
<script>
    function showHint(str) {
  if (str.length==0) { 
    document.getElementById("txtHint").innerHTML="";
    document.getElementById("txtHint").style.border="0px";
    return;
  }
  if (window.XMLHttpRequest) {

    xmlhttp=new XMLHttpRequest();
  } else { 
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("txtHint").innerHTML=this.responseText;
      document.getElementById("txtHint").style.border="1px solid #A5ACB2";
    }
  }
  xmlhttp.open("GET","SearchJobP.php?q="+str,true);
  xmlhttp.send();
}
  
</script>
</head>


<body id="www-url-cz">
 <div id="main" class="box"> 
    <?php 
include "Header.php"
?>
<?php 
include "menu.php"
?>
   
     <div style="width:100%;border-radius:4%; float:right;margin-top:100px;"class="input-group">
                                      <input type="text"class="form-control" onkeyup="showHint(this.value)" placeholder="Search for...">
                                      
                                      <br><br>
                                    
                                    <div id="txtHint"></div>
                                    
                                    </div>
                                    
                                    
    <?php
include "footer.php"
?>
    </div>
    
</body>
</html>
<?php
}
   else{
       header("Location:../index.php?error=invalid user");
   }        
        
?>
